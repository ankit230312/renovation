
<header class="top-header">
	<!-- contact content -->
	<div class="top-bar">
		<div class="container">
			<div class="header-top py-1">
				<div class="row align-items-center">
					<div class="col-md-6 col-xs-12 col-sm-12 col-lg-6">
						<ul class="header-top-left pull-left">
							<li>

								<!-- <img src="images/WhatsApp.png" alt="" width="20"> -->

								<svg height="20px" width="20px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg"
								xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 52 52"
								style="enable-background:new 0 0 52 52; fill: #fff;" xml:space="preserve">
								<g>
									<g>
										<path d="M26,0C11.663,0,0,11.663,0,26c0,4.891,1.359,9.639,3.937,13.762C2.91,43.36,1.055,50.166,1.035,50.237
										c-0.096,0.352,0.007,0.728,0.27,0.981c0.263,0.253,0.643,0.343,0.989,0.237L12.6,48.285C16.637,50.717,21.26,52,26,52
										c14.337,0,26-11.663,26-26S40.337,0,26,0z M26,50c-4.519,0-8.921-1.263-12.731-3.651c-0.161-0.101-0.346-0.152-0.531-0.152
										c-0.099,0-0.198,0.015-0.294,0.044l-8.999,2.77c0.661-2.413,1.849-6.729,2.538-9.13c0.08-0.278,0.035-0.578-0.122-0.821
										C3.335,35.173,2,30.657,2,26C2,12.767,12.767,2,26,2s24,10.767,24,24S39.233,50,26,50z" />
										<path d="M42.985,32.126c-1.846-1.025-3.418-2.053-4.565-2.803c-0.876-0.572-1.509-0.985-1.973-1.218
										c-1.297-0.647-2.28-0.19-2.654,0.188c-0.047,0.047-0.089,0.098-0.125,0.152c-1.347,2.021-3.106,3.954-3.621,4.058
										c-0.595-0.093-3.38-1.676-6.148-3.981c-2.826-2.355-4.604-4.61-4.865-6.146C20.847,20.51,21.5,19.336,21.5,18
										c0-1.377-3.212-7.126-3.793-7.707c-0.583-0.582-1.896-0.673-3.903-0.273c-0.193,0.039-0.371,0.134-0.511,0.273
										c-0.243,0.243-5.929,6.04-3.227,13.066c2.966,7.711,10.579,16.674,20.285,18.13c1.103,0.165,2.137,0.247,3.105,0.247
										c5.71,0,9.08-2.873,10.029-8.572C43.556,32.747,43.355,32.331,42.985,32.126z M30.648,39.511
										c-10.264-1.539-16.729-11.708-18.715-16.87c-1.97-5.12,1.663-9.685,2.575-10.717c0.742-0.126,1.523-0.179,1.849-0.128
										c0.681,0.947,3.039,5.402,3.143,6.204c0,0.525-0.171,1.256-2.207,3.293C17.105,21.48,17,21.734,17,22c0,5.236,11.044,12.5,13,12.5
										c1.701,0,3.919-2.859,5.182-4.722c0.073,0.003,0.196,0.028,0.371,0.116c0.36,0.181,0.984,0.588,1.773,1.104
										c1.042,0.681,2.426,1.585,4.06,2.522C40.644,37.09,38.57,40.701,30.648,39.511z" />
									</g>
								</g>
								<g>
								</g>
								<g>
								</g>
								<g>
								</g>
								<g>
								</g>
								<g>
								</g>
								<g>
								</g>
								<g>
								</g>
								<g>
								</g>
								<g>
								</g>
								<g>
								</g>
								<g>
								</g>
								<g>
								</g>
								<g>
								</g>
								<g>
								</g>
								<g>
								</g>
							</svg>

							<span>
								+91 7557448060
							</span></li>
							<li><svg height="20px" style="fill: #fff;" viewBox="-17 -82 552 552" width="20px"
								xmlns="http://www.w3.org/2000/svg">
								<path
								d="m58.75 384.675781h400c32.429688-.035156 58.714844-26.316406 58.75-58.75v-271.425781c-.035156-32.429688-26.320312-58.714844-58.75-58.75h-400c-32.429688.035156-58.7148438 26.320312-58.75 58.75v271.425781c.0351562 32.433594 26.320312 58.714844 58.75 58.75zm0-17.5c-9.027344.011719-17.808594-2.957031-24.976562-8.449219l119.625-122.355468c2.21875-2.230469 3.066406-5.480469 2.226562-8.507813-.839844-3.03125-3.238281-5.375-6.285156-6.144531-3.050782-.773438-6.277344.148438-8.457032 2.421875l-118.507812 121.214844c-3.203125-5.972657-4.878906-12.648438-4.875-19.429688v-252.136719l203.355469 172.191407c21.894531 18.636719 54.082031 18.628906 75.960937-.035157l203.183594-172.324218v252.304687c.007812 6.808594-1.679688 13.503907-4.90625 19.492188l-119.21875-121.300781c-3.394531-3.414063-8.90625-3.449219-12.34375-.078126-3.433594 3.382813-3.496094 8.894532-.136719 12.34375l120.28125 122.382813c-7.160156 5.464844-15.917969 8.421875-24.925781 8.410156zm0-353.925781h400c21.34375.03125 39.148438 16.3125 41.078125 37.574219l-214.328125 181.777343c-15.363281 13.101563-37.964844 13.109376-53.335938.019532l-214.5-181.628906c1.835938-21.328126 19.675782-37.710938 41.085938-37.742188zm0 0" />
							</svg> <span> email@email.com</span></li>

						</ul>
					</div>
					<div class=" col-md-6 col-xs-12 col-sm-12 col-lg-6">
						<div class="header-top-right pull-right">
							<ul class="header-top-right">
								<li><img src="images/play-store-icon.png" alt="" width="99">

								</li>


							</ul>



						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<!-- / contact content -->
<div class="Main-menu">

	<div class="logo">

		<a href="index.html"><img src="images/logo.png" alt="logo.png"></a>

	</div>

	<div class="locc-map">
		<i class="fas fa-map-marker-alt"></i>
		<span class="location">

			<select class="form-control">
				<option value="Location">Location</option>
				<option value="saab">Noida</option>
				<option value="saab">Delhi</option>
				<option value="saab">Modinagar</option>
				<option value="saab">Gururam</option>
			</select>
		</span>
	</div>

	<label class="open-search" for="open-search">
		<!-- <i class="fas fa-search"></i> -->
		<!-- <input class="input-open-search" id="open-search" type="checkbox" name="menu" /> -->
		<div class="search">
			<button class="button-search"><i class="fas fa-search"></i></button>
			<input type="text" placeholder="Search For Products" class="input-search" />
		</div>
	</label>


	<div class="mr-5">
		<ul class="right-icon">
			<li class="dropdown user">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
					<svg version="1.1" width="20" id="Layer_1" xmlns="http://www.w3.org/2000/svg"
					xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512"
					style="enable-background:new 0 0 512 512;" xml:space="preserve">
					<g>
						<g>
							<path d="M333.187,237.405c32.761-23.893,54.095-62.561,54.095-106.123C387.282,58.893,328.389,0,256,0
							S124.718,58.893,124.718,131.282c0,43.562,21.333,82.23,54.095,106.123C97.373,268.57,39.385,347.531,39.385,439.795
							c0,39.814,32.391,72.205,72.205,72.205H400.41c39.814,0,72.205-32.391,72.205-72.205
							C472.615,347.531,414.627,268.57,333.187,237.405z M164.103,131.282c0-50.672,41.225-91.897,91.897-91.897
							s91.897,41.225,91.897,91.897S306.672,223.18,256,223.18S164.103,181.954,164.103,131.282z M400.41,472.615H111.59
							c-18.097,0-32.82-14.723-32.82-32.821c0-97.726,79.504-177.231,177.231-177.231s177.231,79.504,177.231,177.231
							C433.231,457.892,418.508,472.615,400.41,472.615z" />
						</g>
					</g>
					<g>
					</g>
					<g>
					</g>
					<g>
					</g>
					<g>
					</g>
					<g>
					</g>
					<g>
					</g>
					<g>
					</g>
					<g>
					</g>
					<g>
					</g>
					<g>
					</g>
					<g>
					</g>
					<g>
					</g>
					<g>
					</g>
					<g>
					</g>
					<g>
					</g>
				</svg>
			</a>
			<ul class="dropdown-menu user-menu">

				<li><a href="#">Profile</a></li>
				<li><a href="#">Order </a></li>
				<li><a href="#">Wallet</a></li>

			</ul>
		</li>
		<li>
			<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg"
			xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 450.391 450.391"
			style="enable-background:new 0 0 450.391 450.391;" xml:space="preserve">
			<g>
				<g>
					<g>
						<path d="M143.673,350.322c-25.969,0-47.02,21.052-47.02,47.02c0,25.969,21.052,47.02,47.02,47.02
						c25.969,0,47.02-21.052,47.02-47.02C190.694,371.374,169.642,350.322,143.673,350.322z M143.673,423.465
						c-14.427,0-26.122-11.695-26.122-26.122c0-14.427,11.695-26.122,26.122-26.122c14.427,0,26.122,11.695,26.122,26.122
						C169.796,411.77,158.1,423.465,143.673,423.465z" />
						<path
						d="M342.204,350.322c-25.969,0-47.02,21.052-47.02,47.02c0,25.969,21.052,47.02,47.02,47.02s47.02-21.052,47.02-47.02
						C389.224,371.374,368.173,350.322,342.204,350.322z M342.204,423.465c-14.427,0-26.122-11.695-26.122-26.122
						c0-14.427,11.695-26.122,26.122-26.122s26.122,11.695,26.122,26.122C368.327,411.77,356.631,423.465,342.204,423.465z" />
						<path d="M448.261,76.037c-2.176-2.377-5.153-3.865-8.359-4.18L99.788,67.155L90.384,38.42
						C83.759,19.211,65.771,6.243,45.453,6.028H10.449C4.678,6.028,0,10.706,0,16.477s4.678,10.449,10.449,10.449h35.004
						c11.361,0.251,21.365,7.546,25.078,18.286l66.351,200.098l-5.224,12.016c-5.827,15.026-4.077,31.938,4.702,45.453
						c8.695,13.274,23.323,21.466,39.184,21.943h203.233c5.771,0,10.449-4.678,10.449-10.449c0-5.771-4.678-10.449-10.449-10.449
						H175.543c-8.957-0.224-17.202-4.936-21.943-12.539c-4.688-7.51-5.651-16.762-2.612-25.078l4.18-9.404l219.951-22.988
						c24.16-2.661,44.034-20.233,49.633-43.886l25.078-105.012C450.96,81.893,450.36,78.492,448.261,76.037z M404.376,185.228
						c-3.392,15.226-16.319,26.457-31.869,27.69l-217.339,22.465L106.58,88.053l320.261,4.702L404.376,185.228z" />
					</g>
				</g>
			</g>
			<g>
			</g>
			<g>
			</g>
			<g>
			</g>
			<g>
			</g>
			<g>
			</g>
			<g>
			</g>
			<g>
			</g>
			<g>
			</g>
			<g>
			</g>
			<g>
			</g>
			<g>
			</g>
			<g>
			</g>
			<g>
			</g>
			<g>
			</g>
			<g>
			</g>
		</svg>
		<span class="cart-count">9</span>
	</li>
</ul>
</div>

</div>

<nav class="navbar navbar-expand-lg navbar-light bg-light p-0 menu-bar">

	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
	aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
	<!-- <span class="navbar-toggler-icon"></span> -->
	<span>Categories</span>
</button>
<div class="collapse navbar-collapse" id="navbarNav">
	<ul class="navbar-nav nav-row">


		<li class="nav-item">
			<a class="nav-link" href="#">Fruits</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="#">Vegetables</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="#">Fruits</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="#">Fruits</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="#">Beverages</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="#">Beverages</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="#">Beverages</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="#">Baby Health Store</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="#">Contact</a>
		</li>
		<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
			aria-haspopup="true" aria-expanded="false">
			More
		</a>
		<div class="dropdown-menu" aria-labelledby="navbarDropdown">
			<a class="dropdown-item" href="#">Fruits</a>
			<a class="dropdown-item" href="#">Fruits</a>
			<a class="dropdown-item" href="#">Fruits</a>
			<a class="dropdown-item" href="#">Fruits</a>
			<a class="dropdown-item" href="#">Fruits</a>
			<a class="dropdown-item" href="#">Fruits</a>
			<a class="dropdown-item" href="#">Fruits</a>
			<a class="dropdown-item" href="#">Fruits</a>

		</div>
	</li>

</ul>
</div>
</nav>

</header>