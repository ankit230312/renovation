 <style>
 	  @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&amp;display=swap');
 	  p{
 	  	font-size: 13px;
 	  }
 </style>

 <section>
                    <div class="container">
                    	<div class="row">

          <div class="col-12">
            <br>
            <div class="section_title our-publication"> <h3 class="h3"> FAQ </h3></div>

          </div>





        </div>
                        <div class="row">
                            <div class="col-md-12">
                                
                              <?=$all_data->faq?>
                            </div>
                        </div>
                        
                    </div>
                </section>