
<section>
<div class="container">
  <div  class="row justify-content-md-center" ><br>
    <center><h1><strong style="color: red;"><br><br>
   We will be coming soon to this area.
    </strong><br><br>
<a href="<?=base_url('home')?>"><button class="btn btn-primary"> Back To Home</button></a>
</h1></center>
</div><br>

<div class="row justify-content-md-center" ><br>
	<!-- <center>
    <img src="<?=base_url("assets/images/location.gif")?>">
</center> -->
<br>
<br>
  </div>
</div>
</section>
