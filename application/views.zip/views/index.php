<?php include 'layout/header.php'; ?>
<?php include $page_name.'.php'; ?>

<?php include 'layout/footer.php'; ?>